package com.cnrobin.mms_sellpart;

/**
 * Created by cnrobin on 17-10-12.
 * Just Enjoy It!!!
 */

public interface BaseView<T> {
    void setPresenter(T presenter);
}
